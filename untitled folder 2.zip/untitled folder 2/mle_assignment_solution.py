#!/usr/bin/env python3
"""
MLE Assignment Solution - Classification Problem
===============================================

This script implements a comprehensive machine learning solution for the classification dataset.
It includes data preprocessing, feature engineering, model training, evaluation, and deployment-ready code.

Author: MLE Candidate
Date: 2024
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score, 
    roc_curve, precision_recall_curve, accuracy_score
)
from sklearn.impute import SimpleImputer
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

class ClassificationMLESolution:
    """
    Comprehensive ML solution for classification problem.
    
    This class implements a complete machine learning pipeline including:
    - Data loading and exploration
    - Data preprocessing and feature engineering
    - Model training and hyperparameter tuning
    - Model evaluation and interpretation
    - Deployment-ready predictions
    """
    
    def __init__(self, data_path='classification_dataset.csv'):
        """
        Initialize the ML solution.
        
        Args:
            data_path (str): Path to the CSV dataset
        """
        self.data_path = data_path
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.scaler = StandardScaler()
        self.imputer = SimpleImputer(strategy='mean')
        self.best_model = None
        self.feature_importance = None
        
    def load_and_explore_data(self):
        """
        Load the dataset and perform initial exploration.
        """
        print("=== Loading and Exploring Data ===")
        
        # Load data
        self.data = pd.read_csv(self.data_path)
        print(f"Dataset shape: {self.data.shape}")
        print(f"Features: {self.data.shape[1]-1}")
        print(f"Samples: {self.data.shape[0]}")
        
        # Basic info
        print("\nDataset Info:")
        print(self.data.info())
        
        # Check for missing values
        print("\nMissing values:")
        missing_values = self.data.isnull().sum()
        print(missing_values[missing_values > 0])
        
        # Target distribution
        print("\nTarget distribution:")
        target_counts = self.data['target'].value_counts()
        print(target_counts)
        print(f"Class balance: {target_counts[0]/len(self.data):.3f} vs {target_counts[1]/len(self.data):.3f}")
        
        # Basic statistics
        print("\nBasic statistics:")
        print(self.data.describe())
        
        return self.data
    
    def preprocess_data(self):
        """
        Preprocess the data for machine learning.
        """
        print("\n=== Preprocessing Data ===")
        
        # Separate features and target
        X = self.data.drop('target', axis=1)
        y = self.data['target']
        
        # Handle missing values
        print("Handling missing values...")
        X_imputed = pd.DataFrame(
            self.imputer.fit_transform(X),
            columns=X.columns,
            index=X.index
        )
        
        # Feature scaling
        print("Scaling features...")
        X_scaled = pd.DataFrame(
            self.scaler.fit_transform(X_imputed),
            columns=X_imputed.columns,
            index=X_imputed.index
        )
        
        # Split the data
        print("Splitting data into train/test sets...")
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42, stratify=y
        )
        
        print(f"Training set: {self.X_train.shape}")
        print(f"Test set: {self.X_test.shape}")
        
        return self.X_train, self.X_test, self.y_train, self.y_test
    
    def train_models(self):
        """
        Train multiple models and select the best one.
        """
        print("\n=== Training Models ===")
        
        models = {
            'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
            'Gradient Boosting': GradientBoostingClassifier(random_state=42),
            'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
            'SVM': SVC(random_state=42, probability=True)
        }
        
        results = {}
        
        for name, model in models.items():
            print(f"Training {name}...")
            
            # Cross-validation
            cv_scores = cross_val_score(model, self.X_train, self.y_train, cv=5, scoring='accuracy')
            
            # Train on full training set
            model.fit(self.X_train, self.y_train)
            
            # Predictions
            y_pred = model.predict(self.X_test)
            y_pred_proba = model.predict_proba(self.X_test)[:, 1] if hasattr(model, 'predict_proba') else None
            
            # Metrics
            accuracy = accuracy_score(self.y_test, y_pred)
            auc = roc_auc_score(self.y_test, y_pred_proba) if y_pred_proba is not None else None
            
            results[name] = {
                'model': model,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'accuracy': accuracy,
                'auc': auc,
                'predictions': y_pred,
                'probabilities': y_pred_proba
            }
            
            print(f"  CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
            print(f"  Test Accuracy: {accuracy:.4f}")
            if auc:
                print(f"  Test AUC: {auc:.4f}")
        
        # Select best model based on AUC
        best_model_name = max(results.keys(), key=lambda x: results[x]['auc'] if results[x]['auc'] else 0)
        self.best_model = results[best_model_name]['model']
        
        print(f"\nBest model: {best_model_name}")
        print(f"Best AUC: {results[best_model_name]['auc']:.4f}")
        
        return results
    
    def hyperparameter_tuning(self):
        """
        Perform hyperparameter tuning on the best model.
        """
        print("\n=== Hyperparameter Tuning ===")
        
        if isinstance(self.best_model, RandomForestClassifier):
            param_grid = {
                'n_estimators': [50, 100, 200],
                'max_depth': [10, 20, None],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4]
            }
        elif isinstance(self.best_model, GradientBoostingClassifier):
            param_grid = {
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7],
                'subsample': [0.8, 0.9, 1.0]
            }
        else:
            print("Skipping hyperparameter tuning for this model type.")
            return self.best_model
        
        # Grid search
        grid_search = GridSearchCV(
            self.best_model.__class__(**{k: v for k, v in self.best_model.get_params().items() 
                                       if k not in param_grid.keys()}),
            param_grid,
            cv=5,
            scoring='roc_auc',
            n_jobs=-1,
            verbose=1
        )
        
        grid_search.fit(self.X_train, self.y_train)
        
        print(f"Best parameters: {grid_search.best_params_}")
        print(f"Best CV score: {grid_search.best_score_:.4f}")
        
        self.best_model = grid_search.best_estimator_
        return self.best_model
    
    def evaluate_model(self):
        """
        Comprehensive model evaluation.
        """
        print("\n=== Model Evaluation ===")
        
        # Predictions
        y_pred = self.best_model.predict(self.X_test)
        y_pred_proba = self.best_model.predict_proba(self.X_test)[:, 1]
        
        # Classification report
        print("Classification Report:")
        print(classification_report(self.y_test, y_pred))
        
        # Confusion matrix
        cm = confusion_matrix(self.y_test, y_pred)
        print("Confusion Matrix:")
        print(cm)
        
        # ROC curve
        fpr, tpr, _ = roc_curve(self.y_test, y_pred_proba)
        auc_score = roc_auc_score(self.y_test, y_pred_proba)
        
        plt.figure(figsize=(12, 4))
        
        # ROC curve
        plt.subplot(1, 2, 1)
        plt.plot(fpr, tpr, label=f'ROC curve (AUC = {auc_score:.3f})')
        plt.plot([0, 1], [0, 1], 'k--', label='Random')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve')
        plt.legend()
        plt.grid(True)
        
        # Precision-Recall curve
        plt.subplot(1, 2, 2)
        precision, recall, _ = precision_recall_curve(self.y_test, y_pred_proba)
        plt.plot(recall, precision, label='Precision-Recall curve')
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title('Precision-Recall Curve')
        plt.legend()
        plt.grid(True)
        
        plt.tight_layout()
        plt.savefig('model_evaluation.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        # Feature importance (if available)
        if hasattr(self.best_model, 'feature_importances_'):
            self.feature_importance = pd.DataFrame({
                'feature': self.X_train.columns,
                'importance': self.best_model.feature_importances_
            }).sort_values('importance', ascending=False)
            
            print("\nTop 10 Most Important Features:")
            print(self.feature_importance.head(10))
            
            # Plot feature importance
            plt.figure(figsize=(10, 6))
            top_features = self.feature_importance.head(15)
            plt.barh(range(len(top_features)), top_features['importance'])
            plt.yticks(range(len(top_features)), top_features['feature'])
            plt.xlabel('Feature Importance')
            plt.title('Feature Importance')
            plt.gca().invert_yaxis()
            plt.tight_layout()
            plt.savefig('feature_importance.png', dpi=300, bbox_inches='tight')
            plt.show()
    
    def create_deployment_code(self):
        """
        Create deployment-ready code for the model.
        """
        print("\n=== Creating Deployment Code ===")
        
        deployment_code = '''
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

class ClassificationPredictor:
    """
    Deployment-ready classifier for the MLE assignment.
    """
    
    def __init__(self, model_path='best_model.pkl', scaler_path='scaler.pkl', imputer_path='imputer.pkl'):
        """
        Initialize the predictor with trained model and preprocessors.
        
        Args:
            model_path (str): Path to the trained model
            scaler_path (str): Path to the fitted scaler
            imputer_path (str): Path to the fitted imputer
        """
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)
        
        with open(scaler_path, 'rb') as f:
            self.scaler = pickle.load(f)
            
        with open(imputer_path, 'rb') as f:
            self.imputer = pickle.load(f)
    
    def preprocess_input(self, data):
        """
        Preprocess input data using the same pipeline as training.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            pd.DataFrame: Preprocessed features
        """
        # Handle missing values
        data_imputed = pd.DataFrame(
            self.imputer.transform(data),
            columns=data.columns,
            index=data.index
        )
        
        # Scale features
        data_scaled = pd.DataFrame(
            self.scaler.transform(data_imputed),
            columns=data_imputed.columns,
            index=data_imputed.index
        )
        
        return data_scaled
    
    def predict(self, data):
        """
        Make predictions on new data.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            np.array: Predicted classes
        """
        data_processed = self.preprocess_input(data)
        return self.model.predict(data_processed)
    
    def predict_proba(self, data):
        """
        Get prediction probabilities.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            np.array: Prediction probabilities
        """
        data_processed = self.preprocess_input(data)
        return self.model.predict_proba(data_processed)

# Example usage:
if __name__ == "__main__":
    # Load the predictor
    predictor = ClassificationPredictor()
    
    # Example prediction
    sample_data = pd.DataFrame({
        'feature_0': [1000.0],
        'feature_1': [2000.0],
        # ... add all features
    })
    
    prediction = predictor.predict(sample_data)
    probability = predictor.predict_proba(sample_data)
    
    print(f"Prediction: {prediction[0]}")
    print(f"Probability: {probability[0]}")
'''
        
        with open('deployment_code.py', 'w') as f:
            f.write(deployment_code)
        
        print("Deployment code saved to 'deployment_code.py'")
    
    def save_model(self):
        """
        Save the trained model and preprocessors.
        """
        print("\n=== Saving Model ===")
        
        import pickle
        
        # Save model
        with open('best_model.pkl', 'wb') as f:
            pickle.dump(self.best_model, f)
        
        # Save scaler
        with open('scaler.pkl', 'wb') as f:
            pickle.dump(self.scaler, f)
        
        # Save imputer
        with open('imputer.pkl', 'wb') as f:
            pickle.dump(self.imputer, f)
        
        print("Model and preprocessors saved successfully!")
    
    def run_complete_pipeline(self):
        """
        Run the complete ML pipeline.
        """
        print("=" * 50)
        print("MLE ASSIGNMENT SOLUTION - CLASSIFICATION PROBLEM")
        print("=" * 50)
        
        # Load and explore data
        self.load_and_explore_data()
        
        # Preprocess data
        self.preprocess_data()
        
        # Train models
        results = self.train_models()
        
        # Hyperparameter tuning
        self.hyperparameter_tuning()
        
        # Evaluate model
        self.evaluate_model()
        
        # Create deployment code
        self.create_deployment_code()
        
        # Save model
        self.save_model()
        
        print("\n" + "=" * 50)
        print("PIPELINE COMPLETED SUCCESSFULLY!")
        print("=" * 50)
        
        return results

def main():
    """
    Main function to run the complete ML solution.
    """
    # Initialize the solution
    solution = ClassificationMLESolution()
    
    # Run the complete pipeline
    results = solution.run_complete_pipeline()
    
    return solution, results

if __name__ == "__main__":
    solution, results = main() 