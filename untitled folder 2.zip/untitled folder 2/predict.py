#!/usr/bin/env python3
"""
Prediction Script for MLE Assignment
====================================

This script demonstrates how to use the trained classification model
to make predictions on new data.

Usage:
    python predict.py

Author: MLE Candidate
Date: 2024
"""

import pandas as pd
import numpy as np
import pickle
import warnings
warnings.filterwarnings('ignore')

class ModelPredictor:
    """
    A simple class to load the trained model and make predictions.
    """
    
    def __init__(self, model_path='best_model.pkl', scaler_path='scaler.pkl', imputer_path='imputer.pkl'):
        """
        Initialize the predictor by loading the trained model and preprocessors.
        
        Args:
            model_path (str): Path to the saved model
            scaler_path (str): Path to the saved scaler
            imputer_path (str): Path to the saved imputer
        """
        try:
            # Load the trained model
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            print(f"✓ Model loaded from {model_path}")
            
            # Load the scaler
            with open(scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)
            print(f"✓ Scaler loaded from {scaler_path}")
            
            # Load the imputer
            with open(imputer_path, 'rb') as f:
                self.imputer = pickle.load(f)
            print(f"✓ Imputer loaded from {imputer_path}")
            
        except FileNotFoundError as e:
            print(f"❌ Error: Could not find model files. Please run the training script first.")
            print(f"Missing file: {e}")
            raise
        except Exception as e:
            print(f"❌ Error loading model: {e}")
            raise
    
    def preprocess_data(self, data):
        """
        Preprocess the input data using the same pipeline as training.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            pd.DataFrame: Preprocessed features
        """
        # Handle missing values
        data_imputed = pd.DataFrame(
            self.imputer.transform(data),
            columns=data.columns,
            index=data.index
        )
        
        # Scale features
        data_scaled = pd.DataFrame(
            self.scaler.transform(data_imputed),
            columns=data_imputed.columns,
            index=data_imputed.index
        )
        
        return data_scaled
    
    def predict(self, data):
        """
        Make predictions on new data.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            np.array: Predicted classes (0 or 1)
        """
        data_processed = self.preprocess_data(data)
        predictions = self.model.predict(data_processed)
        return predictions
    
    def predict_proba(self, data):
        """
        Get prediction probabilities.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            np.array: Prediction probabilities [P(class=0), P(class=1)]
        """
        data_processed = self.preprocess_data(data)
        probabilities = self.model.predict_proba(data_processed)
        return probabilities
    
    def predict_with_confidence(self, data):
        """
        Make predictions with confidence scores.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            tuple: (predictions, confidence_scores)
        """
        probabilities = self.predict_proba(data)
        predictions = self.predict(data)
        
        # Confidence is the maximum probability for each prediction
        confidence_scores = np.max(probabilities, axis=1)
        
        return predictions, confidence_scores

def create_sample_data():
    """
    Create sample data for demonstration purposes.
    This simulates new data that you might want to predict on.
    
    Returns:
        pd.DataFrame: Sample data with all required features
    """
    # Create sample data based on the original dataset statistics
    np.random.seed(42)
    
    # Generate 10 sample records
    n_samples = 10
    
    sample_data = pd.DataFrame({
        'feature_0': np.random.uniform(1000, 3000, n_samples),
        'feature_1': np.random.uniform(2000, 6000, n_samples),
        'feature_2': np.random.uniform(0.2, 0.8, n_samples),
        'feature_3': np.random.randint(1, 50, n_samples),
        'feature_4': np.random.uniform(-1000, 5000, n_samples),
        'feature_5': np.random.uniform(0, 5, n_samples),
        'feature_6': np.random.uniform(0, 2000, n_samples),
        'feature_7': np.random.uniform(0, 10000, n_samples),
        'feature_8': np.random.randint(0, 100, n_samples),
        'feature_9': np.random.uniform(-500, 1500, n_samples),
        'feature_10': np.random.uniform(-100, 1000, n_samples),
        'feature_11': np.random.randint(600, 700, n_samples),
        'feature_12': np.random.uniform(0, 1000, n_samples),
        'feature_13': np.random.randint(1, 20, n_samples),
        'feature_14': np.random.randint(0, 10, n_samples),
        'feature_15': np.random.uniform(0.3, 1.1, n_samples),
        'feature_16': np.random.randint(0, 5, n_samples),
        'feature_17': np.random.uniform(0.2, 1.3, n_samples),
        'feature_18': np.random.randint(0, 5, n_samples),
        'feature_19': np.random.randint(0, 5, n_samples),
        'feature_20': np.random.uniform(0, 2000, n_samples),
        'feature_21': np.random.randint(0, 15000, n_samples),
        'feature_22': np.random.randint(0, 15000, n_samples),
        'feature_23': np.random.randint(0, 5, n_samples),
        'feature_24': np.random.randint(0, 5, n_samples),
        'feature_25': np.random.randint(0, 5, n_samples),
        'feature_26': np.random.randint(0, 5, n_samples),
        'feature_27': np.random.randint(0, 5, n_samples),
        'feature_28': np.random.randint(0, 5, n_samples),
        'feature_29': np.random.randint(0, 5, n_samples),
        'feature_30': np.random.randint(0, 5, n_samples),
        'feature_31': np.random.randint(0, 5, n_samples),
        'feature_32': np.random.randint(0, 5, n_samples),
        'feature_33': np.random.randint(0, 5, n_samples),
        'feature_34': np.random.uniform(0, 2000, n_samples),
        'feature_35': np.random.randint(0, 5, n_samples),
        'feature_36': np.random.randint(0, 5, n_samples),
        'feature_37': np.random.randint(0, 5, n_samples),
        'feature_38': np.random.uniform(0, 2000, n_samples),
        'feature_39': np.random.uniform(0, 2000, n_samples),
        'feature_40': np.random.uniform(0, 2000, n_samples),
        'feature_41': np.random.uniform(0, 2000, n_samples),
        'feature_42': np.random.uniform(0, 2000, n_samples),
        'feature_43': np.random.uniform(0, 2000, n_samples),
        'feature_44': np.random.uniform(0, 2000, n_samples),
        'feature_45': np.random.uniform(0, 2000, n_samples),
        'feature_46': np.random.uniform(0, 2000, n_samples),
        'feature_47': np.random.uniform(0, 2000, n_samples),
        'feature_48': np.random.uniform(0, 2000, n_samples),
    })
    
    return sample_data

def demonstrate_predictions():
    """
    Demonstrate how to use the trained model for predictions.
    """
    print("=" * 60)
    print("MLE ASSIGNMENT - PREDICTION DEMONSTRATION")
    print("=" * 60)
    
    try:
        # Initialize the predictor
        print("\n1. Loading the trained model...")
        predictor = ModelPredictor()
        
        # Create sample data
        print("\n2. Creating sample data for prediction...")
        sample_data = create_sample_data()
        print(f"Sample data shape: {sample_data.shape}")
        print("\nFirst few rows of sample data:")
        print(sample_data.head(3))
        
        # Make predictions
        print("\n3. Making predictions...")
        predictions = predictor.predict(sample_data)
        probabilities = predictor.predict_proba(sample_data)
        predictions_with_confidence = predictor.predict_with_confidence(sample_data)
        
        # Display results
        print("\n4. Prediction Results:")
        print("-" * 40)
        
        for i in range(len(sample_data)):
            pred_class = predictions[i]
            prob_class_0 = probabilities[i][0]
            prob_class_1 = probabilities[i][1]
            confidence = predictions_with_confidence[1][i]
            
            print(f"Sample {i+1}:")
            print(f"  Prediction: Class {pred_class}")
            print(f"  Probability Class 0: {prob_class_0:.3f}")
            print(f"  Probability Class 1: {prob_class_1:.3f}")
            print(f"  Confidence: {confidence:.3f}")
            print()
        
        # Summary statistics
        print("5. Summary Statistics:")
        print("-" * 40)
        print(f"Total predictions: {len(predictions)}")
        print(f"Class 0 predictions: {np.sum(predictions == 0)}")
        print(f"Class 1 predictions: {np.sum(predictions == 1)}")
        print(f"Average confidence: {np.mean(predictions_with_confidence[1]):.3f}")
        
        # Demonstrate batch prediction
        print("\n6. Batch Prediction Example:")
        print("-" * 40)
        
        # Create a single sample for demonstration
        single_sample = sample_data.iloc[0:1]
        single_prediction = predictor.predict(single_sample)
        single_probability = predictor.predict_proba(single_sample)
        
        print(f"Single sample prediction: Class {single_prediction[0]}")
        print(f"Single sample probability: {single_probability[0]}")
        
        print("\n" + "=" * 60)
        print("PREDICTION DEMONSTRATION COMPLETED!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error during prediction: {e}")
        print("Please make sure you have run the training script first.")
        return None

def predict_from_csv(csv_path):
    """
    Make predictions from a CSV file.
    
    Args:
        csv_path (str): Path to CSV file with features
    """
    try:
        print(f"\nMaking predictions from CSV file: {csv_path}")
        
        # Load the predictor
        predictor = ModelPredictor()
        
        # Load data from CSV
        data = pd.read_csv(csv_path)
        print(f"Loaded {len(data)} samples from CSV")
        
        # Make predictions
        predictions = predictor.predict(data)
        probabilities = predictor.predict_proba(data)
        
        # Add predictions to the dataframe
        data['predicted_class'] = predictions
        data['probability_class_0'] = probabilities[:, 0]
        data['probability_class_1'] = probabilities[:, 1]
        
        # Save results
        output_path = csv_path.replace('.csv', '_predictions.csv')
        data.to_csv(output_path, index=False)
        print(f"Predictions saved to: {output_path}")
        
        return data
        
    except Exception as e:
        print(f"❌ Error predicting from CSV: {e}")
        return None

def main():
    """
    Main function to run the prediction demonstration.
    """
    import sys
    
    if len(sys.argv) > 1:
        # If CSV file is provided as argument
        csv_path = sys.argv[1]
        predict_from_csv(csv_path)
    else:
        # Run the demonstration
        demonstrate_predictions()

if __name__ == "__main__":
    main() 