
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

class ClassificationPredictor:
    """
    Deployment-ready classifier for the MLE assignment.
    """
    
    def __init__(self, model_path='best_model.pkl', scaler_path='scaler.pkl', imputer_path='imputer.pkl'):
        """
        Initialize the predictor with trained model and preprocessors.
        
        Args:
            model_path (str): Path to the trained model
            scaler_path (str): Path to the fitted scaler
            imputer_path (str): Path to the fitted imputer
        """
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)
        
        with open(scaler_path, 'rb') as f:
            self.scaler = pickle.load(f)
            
        with open(imputer_path, 'rb') as f:
            self.imputer = pickle.load(f)
    
    def preprocess_input(self, data):
        """
        Preprocess input data using the same pipeline as training.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            pd.DataFrame: Preprocessed features
        """
        # Handle missing values
        data_imputed = pd.DataFrame(
            self.imputer.transform(data),
            columns=data.columns,
            index=data.index
        )
        
        # Scale features
        data_scaled = pd.DataFrame(
            self.scaler.transform(data_imputed),
            columns=data_imputed.columns,
            index=data_imputed.index
        )
        
        return data_scaled
    
    def predict(self, data):
        """
        Make predictions on new data.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            np.array: Predicted classes
        """
        data_processed = self.preprocess_input(data)
        return self.model.predict(data_processed)
    
    def predict_proba(self, data):
        """
        Get prediction probabilities.
        
        Args:
            data (pd.DataFrame): Input features
            
        Returns:
            np.array: Prediction probabilities
        """
        data_processed = self.preprocess_input(data)
        return self.model.predict_proba(data_processed)

# Example usage:
if __name__ == "__main__":
    # Load the predictor
    predictor = ClassificationPredictor()
    
    # Example prediction
    sample_data = pd.DataFrame({
        'feature_0': [1000.0],
        'feature_1': [2000.0],
        # ... add all features
    })
    
    prediction = predictor.predict(sample_data)
    probability = predictor.predict_proba(sample_data)
    
    print(f"Prediction: {prediction[0]}")
    print(f"Probability: {probability[0]}")
