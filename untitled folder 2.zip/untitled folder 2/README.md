# MLE Assignment Solution - Classification Problem

## Overview

This repository contains a comprehensive machine learning solution for a binary classification problem. The solution implements a complete ML pipeline including data preprocessing, model training, evaluation, and deployment-ready code.

## Problem Statement

Given a classification dataset with 49 features and a binary target variable, the goal is to:
1. Build a robust classification model
2. Evaluate model performance using appropriate metrics
3. Identify important features
4. Create deployment-ready code

## Solution Architecture

The solution is implemented as a Python class `ClassificationMLESolution` that provides:

### 1. Data Loading and Exploration
- Load the CSV dataset
- Perform initial data exploration
- Analyze missing values and target distribution
- Generate basic statistics

### 2. Data Preprocessing
- Handle missing values using mean imputation
- Scale features using StandardScaler
- Split data into training and test sets (80/20 split with stratification)

### 3. Model Training
- Train multiple models:
  - Random Forest
  - Gradient Boosting
  - Logistic Regression
  - Support Vector Machine
- Perform cross-validation for model selection
- Select the best model based on AUC score

### 4. Hyperparameter Tuning
- Use GridSearchCV for hyperparameter optimization
- Optimize based on ROC-AUC score
- Support for Random Forest and Gradient Boosting tuning

### 5. Model Evaluation
- Classification report (precision, recall, F1-score)
- Confusion matrix
- ROC curve and AUC score
- Precision-Recall curve
- Feature importance analysis (for tree-based models)

### 6. Deployment
- Save trained model and preprocessors
- Generate deployment-ready code
- Create a `ClassificationPredictor` class for easy integration

## Files Structure

```
├── mle_assignment_solution.py    # Main solution implementation
├── predict.py                    # Prediction script for new data
├── classification_dataset.csv     # Input dataset
├── sample_data_for_prediction.csv # Sample data for testing predictions
├── requirements.txt              # Python dependencies
├── README.md                    # This file
├── deployment_code.py           # Generated deployment code
├── best_model.pkl              # Saved trained model
├── scaler.pkl                  # Saved scaler
├── imputer.pkl                 # Saved imputer
├── model_evaluation.png        # Generated evaluation plots
└── feature_importance.png      # Generated feature importance plot
```

## Installation and Usage

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Complete Pipeline

```bash
python mle_assignment_solution.py
```

### 3. Make Predictions on New Data

#### Option A: Use the Prediction Script (Recommended)

```bash
# Run demonstration with generated sample data
python predict.py

# Make predictions from a CSV file
python predict.py your_data.csv
```

#### Option B: Use the Deployment Code

```python
from deployment_code import ClassificationPredictor

# Initialize predictor
predictor = ClassificationPredictor()

# Make predictions
sample_data = pd.DataFrame({
    'feature_0': [1000.0],
    'feature_1': [2000.0],
    # ... add all features
})

prediction = predictor.predict(sample_data)
probability = predictor.predict_proba(sample_data)
```

### 4. Example Prediction Output

The prediction script provides:
- **Class predictions**: 0 or 1
- **Probability scores**: P(class=0) and P(class=1)
- **Confidence scores**: Maximum probability for each prediction
- **Summary statistics**: Distribution of predictions and average confidence

Example output:
```
Sample 1:
  Prediction: Class 0
  Probability Class 0: 0.772
  Probability Class 1: 0.228
  Confidence: 0.772
```

## Key Features

### 1. Comprehensive Data Analysis
- Automatic detection of missing values
- Target distribution analysis
- Statistical summary of features

### 2. Robust Preprocessing Pipeline
- Missing value imputation
- Feature scaling
- Stratified train-test split

### 3. Multiple Model Comparison
- Ensemble methods (Random Forest, Gradient Boosting)
- Linear models (Logistic Regression)
- Non-linear models (SVM)
- Cross-validation for reliable performance estimation

### 4. Advanced Evaluation Metrics
- ROC-AUC for model selection
- Precision-Recall curves
- Feature importance analysis
- Comprehensive classification reports

### 5. Production-Ready Code
- Modular design with clear separation of concerns
- Comprehensive error handling
- Easy-to-use deployment interface
- Saved models and preprocessors for reproducibility

### 6. Easy Prediction Interface
- Simple command-line interface for predictions
- Support for CSV file input
- Detailed prediction results with confidence scores
- Batch prediction capabilities

## Model Performance

The solution automatically selects the best performing model based on ROC-AUC score. Typical performance metrics include:

- **Accuracy**: Measures overall prediction accuracy
- **AUC**: Area Under the ROC Curve (primary metric for model selection)
- **Precision**: True positives / (True positives + False positives)
- **Recall**: True positives / (True positives + False negatives)
- **F1-Score**: Harmonic mean of precision and recall

## Feature Engineering

The solution includes:
- Automatic missing value handling
- Feature scaling for algorithms that require it
- Feature importance analysis for interpretable models

## Deployment Considerations

The deployment code provides:
- Easy model loading and prediction
- Consistent preprocessing pipeline
- Error handling for edge cases
- Example usage patterns

## Prediction Usage Examples

### 1. Command Line Usage

```bash
# Demonstrate with sample data
python predict.py

# Predict from CSV file
python predict.py new_data.csv

# The script will create a new file: new_data_predictions.csv
```

### 2. Programmatic Usage

```python
from predict import ModelPredictor

# Initialize predictor
predictor = ModelPredictor()

# Make predictions
predictions = predictor.predict(your_data)
probabilities = predictor.predict_proba(your_data)
predictions_with_confidence = predictor.predict_with_confidence(your_data)
```

### 3. CSV File Format

Your CSV file should contain all 49 features with the same column names as the training data:
- `feature_0`, `feature_1`, ..., `feature_48`
- No target column needed
- Missing values will be automatically handled

## Extensibility

The solution is designed to be easily extensible:
- Add new models by updating the `models` dictionary
- Modify preprocessing steps in the `preprocess_data` method
- Add new evaluation metrics in the `evaluate_model` method
- Customize hyperparameter grids for different models

## Best Practices Implemented

1. **Reproducibility**: Fixed random seeds and saved models
2. **Cross-validation**: Reliable performance estimation
3. **Stratified sampling**: Maintains class balance
4. **Comprehensive evaluation**: Multiple metrics and visualizations
5. **Production readiness**: Deployment-ready code and saved artifacts
6. **Documentation**: Clear code comments and comprehensive README
7. **Easy prediction interface**: Simple command-line and programmatic access

## Future Improvements

Potential enhancements include:
- Feature selection techniques
- Advanced ensemble methods
- Deep learning models
- Automated hyperparameter optimization (Optuna, Hyperopt)
- Model interpretability tools (SHAP, LIME)
- API deployment with FastAPI or Flask
- Real-time prediction service
- Model versioning and A/B testing

## Contact

For questions or improvements, please refer to the code comments and documentation within the implementation. 